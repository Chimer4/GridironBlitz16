# Gridiron Blitz 16 — Android

A 16-bit style side-scrolling football game for Android phones. Mammoths vs Cyclones, four 2-minute quarters, landscape and full-screen, and it works fully offline.

## Get the APK without installing anything (GitHub, ~5 minutes)

1. Create a free account at github.com if you don't have one, then make a **new repository** (e.g. `gridiron-blitz-16`).
2. On the new repo's page, choose **uploading an existing file** and drag in everything from this folder, including the hidden `.github` folder. (On a computer, unzip first; on some systems you need to show hidden files to see `.github`.)
3. Commit. GitHub starts building straight away: open the **Actions** tab and wait for the **Build APK** run to go green (about 3–4 minutes).
4. Open that run, scroll to **Artifacts**, and download **GridironBlitz16-apk**. It's a zip containing `GridironBlitz16.apk`.
5. On your phone, open the APK. Android will ask you to allow installs from your browser or file manager the first time; allow it and tap **Install**.

## Or build it in Android Studio

Open this folder in Android Studio (Ladybug or newer), let Gradle sync, plug in your phone with USB debugging on, and press **Run**. From the command line: `./gradlew assembleDebug`, then find the APK in `app/build/outputs/apk/debug/`.

## Controls

- **▲ ▼** weave between defenders, **◀** ease off or cut back
- **A — Spin:** a split second where you can't be tackled; knocks over anyone you hit
- **B — Burst:** sprint, drains the meter under the field. On 4th down, B kicks a field goal (opponent's 42 or closer) or punts
- Tap the screen to start or snap. **PAUSE** and **SOUND** sit in the top-left corner; the game also pauses when you leave the app.

## What's inside

- `app/src/main/assets/index.html` — the whole game (canvas, pixel sprites, pixel font, chiptune sound). Edit this to change the game.
- `app/src/main/java/.../MainActivity.java` — a full-screen WebView that runs the game.
- `.github/workflows/build-apk.yml` — the cloud build.

Package name: `com.gridironblitz.game` · minimum Android 7.0.
